#ifdef documentation
=========================================================================

     program: mglPrivateEyelinkReadEDF.c
          by: justin gardner
        date: 04/04/10

=========================================================================
#endif

/////////////////////////
//   include section   //
/////////////////////////
#include "../mgl.h"
#include <edf.h>

///////////////////////////////
//   function declarations   //
///////////////////////////////
void dispEventType(int eventType);
void dispEvent(int eventType,ALLF_DATA *event);
int isEyeUsedMessage(int eventType,ALLF_DATA *event);
int isMGLMessage(int eventType,ALLF_DATA *event);
int getMGLMessage(int eventType,ALLF_DATA *event, double *timePtr,double *segmentNumPtr, double *trialNumPtr, double *blockNumPtr, double *phaseNumPtr, double *taskIDPtr) ;


////////////////////////
//   define section   //
////////////////////////
#define STRLEN 2048
/* this is a hack, taken from opt.h in the EDF example code */
/* it is undocumented in the EyeLink code */
#define NaN 1e8                  /* missing floating-point values*/


//////////////
//   main   //
//////////////
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  int err;

  // parse input arguments
  if (nrhs<1) {
    usageError("mglEyelinkReadEDF");
    return;
  }
 
  // get filename
  char filename[STRLEN];
  mxGetString(prhs[0], filename, STRLEN);

  // get verbose
  int verbose = (int)*(double*)mxGetPr(prhs[1]);

  // open file
  if (verbose) mexPrintf("(mglPrivateEyelinkReadEDF) Opening EDF file %s\n",filename);

  int errval;
  EDFFILE *edf = edf_open_file(filename,verbose,1,1,&errval);
  // and check that we opened correctly
  if (edf == NULL) {
    mexPrintf("(mglPrivateEyelinkReadEDF) Could not open file %s (error %i)\n",filename,errval);
    return;
  }

  // initialize some variables
  int i,eventType,numSamples=0,numFix=0,numSac=0,numBlink=0,numMGLTrials=0,numMGLMessages=0;;
  int numElements = edf_get_element_count(edf);
  int numTrials = edf_get_trial_count(edf);
  int setGazeCoords = 0;
  ALLF_DATA *data;

  // initialize the output structure
  const char *mglFieldname = "mgl";
  const char *fieldNames[] =  {"filename","numElements","numTrials","EDFAPI","preamble","gaze","fixations","saccades","blinks",mglFieldname,"gazeCoords","frameRate"};
  int outDims[2] = {1,1};
  plhs[0] = mxCreateStructArray(1,outDims,12,fieldNames);
  
  // save some info about the EDF file in the output
  mxSetField(plhs[0],0,"filename",mxCreateString(filename));
  mxSetField(plhs[0],0,"numElements",mxCreateDoubleScalar(numElements));
  mxSetField(plhs[0],0,"numTrials",mxCreateDoubleScalar(numTrials));
  mxSetField(plhs[0],0,"EDFAPI",mxCreateString(edf_get_version()));

  // save the preamble
  int preambleLength = edf_get_preamble_text_length(edf);
  char *cbuf = (char *)malloc(preambleLength*sizeof(char));
  edf_get_preamble_text(edf,cbuf,preambleLength);
  mxSetField(plhs[0],0,"preamble",mxCreateString(cbuf));

  // mark beginning of file
  BOOKMARK startOfFile;
  edf_set_bookmark(edf,&startOfFile);

  // count number of samples and events in file
  for (i=0;i<numElements;i++) {
    // get the event type and event pointer
    eventType = edf_get_next_data(edf);
    data = edf_get_float_data(edf);
    if (eventType == SAMPLE_TYPE) numSamples++;
    if (eventType == ENDSACC) numSac++;
    if (eventType == ENDFIX) numFix++;
    if (eventType == ENDBLINK) numBlink++;
    // count MGL messages
    if (eventType == MESSAGEEVENT){
      // new style messages
      if (isMGLMessage(eventType,data)) 
      	numMGLMessages++;
      // old style messages
      else if (strncmp(&(data->fe.message->c),"MGL BEGIN TRIAL",15) == 0) 
        numMGLTrials++;
    }
  }

  // set to whether to return new or old style MGL messages
  int mglEyelinkVersion = (numMGLMessages>0) ? 1 : 0;
  if (verbose)
    mexPrintf("(mglPrivateEyelinkReadEDF) MGL Version %i messages\n",mglEyelinkVersion);

  // set an output fields for the gaze data
  const char *fieldNamesGaze[] =  {"time","x","y","pupil","pix2degX","pix2degY","velocityX","velocityY","whichEye"};
  int outDims2[2] = {1,1};
  mxSetField(plhs[0],0,"gaze",mxCreateStructArray(1,outDims2,9,fieldNamesGaze));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"time",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"time"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"x",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrX = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"x"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"y",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrY = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"y"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"pupil",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrPupil = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"pupil"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"pix2degX",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrPix2DegX = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"pix2degX"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"pix2degY",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrPix2DegY = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"pix2degY"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"velocityX",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrVelX = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"velocityX"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"velocityY",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrVelY = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"velocityY"));
  mxSetField(mxGetField(plhs[0],0,"gaze"),0,"whichEye",mxCreateDoubleMatrix(1,numSamples,mxREAL));
  double *outptrWhichEye = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"gaze"),0,"whichEye"));

  // set output fields for fixations
  const char *fieldNamesFix[] =  {"startTime","endTime","aveH","aveV"};
  int outDimsFix[2] = {1,1};
  mxSetField(plhs[0],0,"fixations",mxCreateStructArray(1,outDimsFix,4,fieldNamesFix));
  mxSetField(mxGetField(plhs[0],0,"fixations"),0,"startTime",mxCreateDoubleMatrix(1,numFix,mxREAL));
  double *outptrFixStartTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"fixations"),0,"startTime"));
  mxSetField(mxGetField(plhs[0],0,"fixations"),0,"endTime",mxCreateDoubleMatrix(1,numFix,mxREAL));
  double *outptrFixEndTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"fixations"),0,"endTime"));
  mxSetField(mxGetField(plhs[0],0,"fixations"),0,"aveH",mxCreateDoubleMatrix(1,numFix,mxREAL));
  double *outptrFixAvgH = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"fixations"),0,"aveH"));
  mxSetField(mxGetField(plhs[0],0,"fixations"),0,"aveV",mxCreateDoubleMatrix(1,numFix,mxREAL));
  double *outptrFixAvgV = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"fixations"),0,"aveV"));

  // set output fields for saccades
  const char *fieldNamesSac[] =  {"startTime","endTime","startH","startV","endH","endV","peakVel"};
  int outDimsSac[2] = {1,1};
  mxSetField(plhs[0],0,"saccades",mxCreateStructArray(1,outDimsFix,7,fieldNamesSac));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"startTime",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacStartTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"startTime"));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"endTime",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacEndTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"endTime"));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"startH",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacStartH = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"startH"));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"startV",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacStartV = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"startV"));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"endH",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacEndH = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"endH"));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"endV",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacEndV = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"endV"));
  mxSetField(mxGetField(plhs[0],0,"saccades"),0,"peakVel",mxCreateDoubleMatrix(1,numSac,mxREAL));
  double *outptrSacPeakVel = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"saccades"),0,"peakVel"));

  // set output fields for blinks
  const char *fieldNamesBlinks[] =  {"startTime","endTime"};
  int outDimsBlinks[2] = {1,1};
  mxSetField(plhs[0],0,"blinks",mxCreateStructArray(1,outDimsBlinks,2,fieldNamesBlinks));
  mxSetField(mxGetField(plhs[0],0,"blinks"),0,"startTime",mxCreateDoubleMatrix(1,numBlink,mxREAL));
  double *outptrBlinkStartTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"blinks"),0,"startTime"));
  mxSetField(mxGetField(plhs[0],0,"blinks"),0,"endTime",mxCreateDoubleMatrix(1,numBlink,mxREAL));
  double *outptrBlinkEndTime = (double *)mxGetPr(mxGetField(mxGetField(plhs[0],0,"blinks"),0,"endTime"));

  // MGL trials
  double *outptrMGLtrial;
  // for version 0, we just have trial markers, and will save those
  if (mglEyelinkVersion == 0) {
    mxSetField(plhs[0],0,mglFieldname,mxCreateDoubleMatrix(2,numMGLTrials,mxREAL));
    outptrMGLtrial = (double *)mxGetPr(mxGetField(plhs[0],0,mglFieldname));
  }
  // for version 1, we have various fields that get set
  else {
    const char *fieldNamesMGL[] =  {"time","segmentNum","trialNum","blockNum","phaseNum","taskID"};
    int outDims[2] = {1,1};
    mxSetField(plhs[0],0,mglFieldname,mxCreateStructArray(1,outDims,6,fieldNamesMGL));
  }

  // gaze coordinates
  mxSetField(plhs[0],0,"gazeCoords",mxCreateDoubleMatrix(1,4,mxREAL));
  double *outptrCoords = (double *)mxGetPr(mxGetField(plhs[0],0,"gazeCoords"));

  // gaze coordinates
  mxSetField(plhs[0],0,"frameRate",mxCreateDoubleMatrix(1,1,mxREAL));
  double *outptrFrameRate = (double *)mxGetPr(mxGetField(plhs[0],0,"frameRate"));

  // go back go beginning of file
  edf_goto_bookmark(edf,&startOfFile);
  
  int currentEye = -1;
  // go through all data in file
  if (verbose) mexPrintf("(mglPrivateEyelinkReadEDF) Looping over samples and events \n");

  for (i=0;i<numElements;i++) {
    // get the event type and event pointer
    eventType = edf_get_next_data(edf);
    data = edf_get_float_data(edf);
    // display event type and info
    if (verbose>2) dispEventType(eventType);
    if (verbose>1) dispEvent(eventType,data); 
    // grab which eye we are recording from
    /* if (isEyeUsedMessage(eventType,data)) currentEye = (int)data->fe.eye; */
    currentEye = 1;
    // get samples
    switch(eventType) {
    case SAMPLE_TYPE:
      *outptrTime++ = (double)data->fs.time;
      *outptrWhichEye++ = currentEye;
      if ((int)data->fs.gxvel[currentEye]==NaN) {
          *outptrX++ = mxGetNaN();
          *outptrY++ = mxGetNaN();
          *outptrPupil++ = mxGetNaN();
          *outptrPix2DegX++ = mxGetNaN();
          *outptrPix2DegY++ = mxGetNaN();
          *outptrVelX++ = mxGetNaN();
          *outptrVelY++ = mxGetNaN();
        }
      else{
        *outptrX++ = (double)data->fs.gx[currentEye];
        *outptrY++ = (double)data->fs.gy[currentEye];
        *outptrPupil++ = (double)data->fs.pa[currentEye];
        *outptrPix2DegX++ = (double)data->fs.rx;
        *outptrPix2DegY++ = (double)data->fs.ry;
        *outptrVelX++ = (double)data->fs.gxvel[currentEye];
        *outptrVelY++ = (double)data->fs.gyvel[currentEye];
      }
      break;
    case ENDFIX:
      *outptrFixStartTime++ = (double)data->fe.sttime;
      *outptrFixEndTime++ = (double)data->fe.entime;
      *outptrFixAvgH++ = (double)data->fe.gavx;
      *outptrFixAvgV++ = (double)data->fe.gavy;
      break;
    case ENDSACC:
      *outptrSacStartTime++ = (double)data->fe.sttime;
      *outptrSacEndTime++ = (double)data->fe.entime;
      *outptrSacStartH++ = (double)data->fe.gstx;
      *outptrSacStartV++ = (double)data->fe.gsty;
      *outptrSacEndH++ = (double)data->fe.genx;
      *outptrSacEndV++ = (double)data->fe.geny;
      *outptrSacPeakVel++ = (double)data->fe.pvel;
      break;
    case ENDBLINK:
      *outptrBlinkStartTime++ = (double)data->fe.sttime;
      *outptrBlinkEndTime++ = (double)data->fe.entime;
      break;
    case MESSAGEEVENT:
      if (mglEyelinkVersion == 0) {
	if (strncmp(&(data->fe.message->c),"MGL BEGIN TRIAL",15) == 0) {
	  char *mglMessage = &(data->fe.message->c);
	  char *tok;
	  tok = strtok(mglMessage," ");
	  tok = strtok(NULL," ");
	  tok = strtok(NULL," ");
	  tok = strtok(NULL," ");
	  *outptrMGLtrial++ = (double)data->fe.sttime;
	  if (tok != NULL) *outptrMGLtrial++ = (double)atoi(tok);
	}
      }
      if ((strncmp(&(data->fe.message->c),"GAZE_COORDS",11) == 0) && (setGazeCoords == 0)) {
        char *gazeCoords = &(data->fe.message->c);
        char *tok;
        tok = strtok(gazeCoords," ");
        tok = strtok(NULL," ");
        *outptrCoords++ = (double)atoi(tok);
        tok = strtok(NULL," ");
        *outptrCoords++ = (double)atoi(tok);
        tok = strtok(NULL," ");
        *outptrCoords++ = (double)atoi(tok);
        tok = strtok(NULL," ");
        *outptrCoords++ = (double)atoi(tok);
        setGazeCoords = 1;
      }
      if (strncmp(&(data->fe.message->c),"FRAMERATE",9) == 0){
        char *msg = &(data->fe.message->c);
        char *tok;
        tok = strtok(msg, " ");
        tok = strtok(NULL," ");
        *outptrFrameRate++ = (double)atof(tok);
      }
      /* if (strncmp(&(data->fe.message->c),"!CAL",4) == 0){ */
      /*   char *calMessage = &(data->fe.message->c); */
      /*   char *tok; */
      /*   tok = strtok(calMessage, " "); */
      /*   tok = strtok(NULL," "); */
      /*   mexPrintf("%s\n", tok); */
      /* } */
      break;
    }
  }

  // return MGL events for version greater than 0
  if (mglEyelinkVersion >= 1) {
    // display number of MGL messages
    if (verbose>0) mexPrintf("(mglPrivateEyelinkReadEDF) Parsing %i MGL messages.\n",numMGLMessages);

    //    const char *fieldNames[] =  {"time","segmentNum","trialNum","blockNum","phaseNum","taskID"};
    // create an array to hold each message info
    mxSetField(mxGetField(plhs[0],0,mglFieldname),0,"time",mxCreateDoubleMatrix(1,numMGLMessages,mxREAL));
    double *timePtr = mxGetPr(mxGetField(mxGetField(plhs[0],0,mglFieldname),0,"time"));
    mxSetField(mxGetField(plhs[0],0,mglFieldname),0,"segmentNum",mxCreateDoubleMatrix(1,numMGLMessages,mxREAL));
    double *segmentNumPtr = mxGetPr(mxGetField(mxGetField(plhs[0],0,mglFieldname),0,"segmentNum"));
    mxSetField(mxGetField(plhs[0],0,mglFieldname),0,"trialNum",mxCreateDoubleMatrix(1,numMGLMessages,mxREAL));
    double *trialNumPtr = mxGetPr(mxGetField(mxGetField(plhs[0],0,mglFieldname),0,"trialNum"));
    mxSetField(mxGetField(plhs[0],0,mglFieldname),0,"blockNum",mxCreateDoubleMatrix(1,numMGLMessages,mxREAL));
    double *blockNumPtr = mxGetPr(mxGetField(mxGetField(plhs[0],0,mglFieldname),0,"blockNum"));
    mxSetField(mxGetField(plhs[0],0,mglFieldname),0,"phaseNum",mxCreateDoubleMatrix(1,numMGLMessages,mxREAL));
    double *phaseNumPtr = mxGetPr(mxGetField(mxGetField(plhs[0],0,mglFieldname),0,"phaseNum"));
    mxSetField(mxGetField(plhs[0],0,mglFieldname),0,"taskID",mxCreateDoubleMatrix(1,numMGLMessages,mxREAL));
    double *taskIDPtr = mxGetPr(mxGetField(mxGetField(plhs[0],0,mglFieldname),0,"taskID"));
    // go back to beginning of file 
    edf_goto_bookmark(edf,&startOfFile); 
    // now cycle through events again, and pick out MGL messages 
    for (i=0;i<numElements;i++) { 
      // get the event type and event pointer 
      eventType = edf_get_next_data(edf); 
      data = edf_get_float_data(edf); 
      // get the MGL message 
      if (isMGLMessage(eventType,data))  {
      	if (getMGLMessage(eventType,data,timePtr,segmentNumPtr,trialNumPtr,blockNumPtr,phaseNumPtr,taskIDPtr)) {
	  // valid message, update pointers
	  timePtr++;
	  segmentNumPtr++;
	  trialNumPtr++;
	  blockNumPtr++;
	  phaseNumPtr++;
	  taskIDPtr++;
	}
      }
    } 
  } 


  // free the bookmark
  edf_free_bookmark(edf,&startOfFile);

  // close file
  err = edf_close_file(edf);
  if (err) {
    mexPrintf("(mglPrivateEyelinkReadEDF) Error %i closing file %s\n",err,filename);
  }
}

   
///////////////////////
//   dispEventType   //
///////////////////////
void dispEventType(int dataType)
{
  mexPrintf("(mglPrivateEyelinkReadEDF) DataType is %i: ",dataType); 
  switch(dataType)  {
    case STARTBLINK:
      mexPrintf("start blink");break;
    case STARTSACC:
      mexPrintf("start sacc");break;
    case STARTFIX:
      mexPrintf("start fix");break;
    case STARTSAMPLES:
      mexPrintf("start samples");break;
    case STARTEVENTS:
      mexPrintf("start events");break;
    case STARTPARSE:
      mexPrintf("start parse");break;
    case ENDBLINK:
      mexPrintf("end blink");break;
    case ENDSACC:
      mexPrintf("end sacc");break;
    case ENDFIX:
      mexPrintf("end fix");break;
    case ENDSAMPLES:
      mexPrintf("end samples");break;
    case ENDEVENTS:
      mexPrintf("end events");break;
    case ENDPARSE:
      mexPrintf("end parse");break;
    case FIXUPDATE:
      mexPrintf("fix update");break;
    case BREAKPARSE:
      mexPrintf("break parse");break;
    case BUTTONEVENT:
      mexPrintf("button event");break;
    case INPUTEVENT:
      mexPrintf("input event");break;
    case MESSAGEEVENT:
      mexPrintf("message event");break;
    case SAMPLE_TYPE:
      mexPrintf("sample type");break;
    case RECORDING_INFO:
      mexPrintf("recording info");break;
    case NO_PENDING_ITEMS:
      mexPrintf("no pending items");break;
      break;
  }
  mexPrintf("\n");
}

//////////////////////////
//   isEyeUsedMessage   //
//////////////////////////
int isEyeUsedMessage(int eventType,ALLF_DATA *event)
{
  if (eventType == MESSAGEEVENT) {
    if (strlen(&(event->fe.message->c)) > 8) {
      if (strncmp(&(event->fe.message->c),"EYE_USED",8) == 0) {
	return 1;
      }
    }
  }
  return 0;
}

//////////////////////
//   isMGLMessage   //
//////////////////////
int isMGLMessage(int eventType,ALLF_DATA *event)
{
  int i;
  if (eventType == MESSAGEEVENT) {
    if ((strlen(&(event->fe.message->c)) > 4) && (strncmp(&(event->fe.message->c),"MGL ",4) == 0)){
      // count how many spaces there are
      int numSpaces = 0;
      char *mglMessage = &(event->fe.message->c);
      while(*mglMessage)
	if (*mglMessage++ == ' ')
	  numSpaces++;
      // if we have more than 3 tokens
      if (numSpaces>3) {
	// and the third token is trial, then we should have 7 tokens
	if (strncmp(&(event->fe.message->c),"MGL BEGIN TRIAL",15) == 0) {
	  return((numSpaces==6) ? 1 : 0);
	}
	// otherwise we should have 8 tokens
	else {
	  return((numSpaces==7) ? 1 : 0);
	}
      }
    }
  }
  return 0;
}


///////////////////
//   dispEvent   //
///////////////////
void dispEvent(int eventType,ALLF_DATA *event)
{
  if (isMGLMessage(eventType,event))
    mexPrintf("%i:%s\n",event->fe.sttime,&(event->fe.message->c));
  else if (eventType == SAMPLE_TYPE) {
    //    fprintf(fid,"(mglPrivateEyelinkReadEDF) Sample eye 0 is %i: pupil [%f %f] head [%f %f] screen [%f %f] pupil size [%f]\n",event->fs.time,event->fs.px[0],event->fs.py[0],event->fs.hx[0],event->fs.hy[0],event->fs.gx[0],event->fs.gy[0],event->fs.pa[0]);
    //    fprintf(fid,"(mglPrivateEyelinkReadEDF) Sample eye 1 is %i: pupil [%f %f] head [%f %f] screen [%f %f] pupil size [%f]\n",event->fs.time,event->fs.px[1],event->fs.py[1],event->fs.hx[1],event->fs.hy[1],event->fs.gx[1],event->fs.gy[1],event->fs.pa[1]);
  }
}


///////////////////////
//   getMGLMessage   //
///////////////////////
int getMGLMessage(int eventType,ALLF_DATA *event, double *timePtr,double *segmentNumPtr, double *trialNumPtr, double *blockNumPtr, double *phaseNumPtr, double *taskIDPtr) 
{
  char *mglMessage = &(event->fe.message->c);
  char *tok;
  tok = strtok(mglMessage," ");
  tok = strtok(NULL," ");
  tok = strtok(NULL," ");
  // set the event time
  *timePtr = (double)event->fe.sttime;
  if (strncmp(tok,"TRIAL",5) == 0) { 
    // set 0 for the 0th segment 
    *segmentNumPtr = 0; 
  } 
  else if (strncmp(tok,"SEGMENT",7) == 0){ 
    // set the segmentPtr to have the correct segment 
    tok = strtok(NULL," "); 
    if (tok != NULL) *segmentNumPtr = (double)atoi(tok); 
  } 
  else if (strncmp(tok,"PHASE",5) == 0){ 
    // phase marker, nothing to do. 
    return(0); 
  }    
  else { 
    mexPrintf("(mglPrivateEyelinkReadEDF) Unknown MGL message %s\n",mglMessage); 
    return(0); 
  } 
  // get the trial umber
  tok = strtok(NULL," ");
  if (tok != NULL) *trialNumPtr = (double)atoi(tok);
  // get the block number 
  tok = strtok(NULL," "); 
  if (tok != NULL) *blockNumPtr = (double)atoi(tok); 
  // get the phase number 
  tok = strtok(NULL," "); 
  if (tok != NULL) *phaseNumPtr = (double)atoi(tok); 
  // get the task ID 
  tok = strtok(NULL," "); 
  if (tok != NULL) *taskIDPtr = (double)atoi(tok); 
  return(1);
}
