% mglGetGammaTable.m
%
%        $Id: mglGetGammaTable.m 18 2006-09-13 15:41:18Z justin $
%      usage: mglGetGammaTable()
%         by: justin gardner
%       date: 05/27/06
%  copyright: (c) 2006 Justin Gardner, Jonas Larsson (GPL see mgl/COPYING)
%    purpose: returns what the gamma table is set to
%       e.g.:
%
%mglOpen
%gammaTable = mglGetGammaTable
