% mglIsCursorVisible.m
%
%           by: Christopher Broussard
%         date: 02/15/11
%    copyright: (c) 2007 Justin Gardner, Jonas Larsson (GPL see mgl/COPYING)
%      purpose: Returns whether or not the cursor is visible on any display.
%        usage: mglIsCursorVisible