public class javaMovie {
    static { System.load("/Users/justin/Desktop/mglMovie/libjavamovie.so"); }
    public static native boolean initMovie();
}
