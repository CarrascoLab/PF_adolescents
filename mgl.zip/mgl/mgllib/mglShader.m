% mglShader.m
%
%        $Id: mglShader.m,v 1.4 2007/01/17 15:49:49 justin Exp $
%      usage: mglShader('command', [args])
%         by: Christopher Broussard
%       date: 11/13/07
%  copyright: (c) 2006 Justin Gardner, Jonas Larsson (GPL see mgl/COPYING)
%    purpose: Performs various shader functions.
%      usage:
%             In