% mglUnbindFrameBufferObject.m
%
%        $Id: mglUnbindFrameBufferObject.m cgb $
%      usage: mglUnbindFrameBufferObject
%         by: Christopher Broussard
%       date: 09/07/10
%  copyright: (c) 2006 Justin Gardner, Jonas Larsson (GPL see mgl/COPYING)
%    purpose: Unbinds a frame buffer object from the current OpenGL context
%			  to allow rendering to the standard frame buffer.
%      usage: mglUnbindFrameBufferObject(fbObject);
