============================================================================
MGL (Matlab GL): A suite of mex/m files for displaying psychophysics stimuli.
SEE http://justingardner.net/mgl for more info
============================================================================
