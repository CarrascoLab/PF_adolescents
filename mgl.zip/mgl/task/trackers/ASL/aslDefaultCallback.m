% aslDefaultCallback.m
%
%      usage: aslDefaultCallback()
%         by: justin gardner
%       date: 09/04/10
%    purpose: 
%
function [task msc] = aslDefaultCallback(task,msc)


