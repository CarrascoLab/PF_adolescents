% mglOpen();
initScreen;
mglClearScreen(22);
mglFlush();
mglEyelinkOpen();
mglScreenCoordinates();
mglEyelinkSetup();
mglEyelinkClose();
% mglClose();