function view = dummyAnalysis(view,params)
