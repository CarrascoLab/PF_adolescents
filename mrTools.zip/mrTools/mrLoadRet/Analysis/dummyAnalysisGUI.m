function params = dummyAnalysisGUI(varargin)

params = [];
