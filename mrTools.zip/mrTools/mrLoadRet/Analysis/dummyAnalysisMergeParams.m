function [mergedParams,mergedData] = dummyAnalysisMergeParams(groupName,oldParams,newParams)

mergedParams = [];
mergedData = [];
