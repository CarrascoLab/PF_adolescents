function [newparams,newdata] = dummyAnalysisReconcileParams(groupName,params,data)

newparams = [];
newdata = [];
