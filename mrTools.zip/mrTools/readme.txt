============================================================================
mrTools: A suite of mex/m files for analysis of functional MRI data
SEE http://justingardner.net/mrTools for more info
============================================================================
